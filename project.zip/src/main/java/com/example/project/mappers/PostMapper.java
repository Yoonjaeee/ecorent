package com.example.project.mappers;

import com.example.project.dto.LoveDto;
import com.example.project.dto.UsersPostDto;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PostMapper {

    @Insert("INSERT INTO post VALUES(NULL, #{postType}, #{postTitle}, #{postContent}, NOW())")
    public void setPost(UsersPostDto postDto);

    @Select("SELECT COUNT(*) FROM post")
    public int getTotalPost();

    @Select("SELECT * FROM post ORDER BY post_num DESC")
    public List<UsersPostDto> getCommunityList();

    @Select("SELECT * FROM POST WHERE post_num = #{postNum}")
    public UsersPostDto viewPost(int id);

    @Delete("DELETE FROM post WHERE post_num=#{postNum}")
    public void removePost(int postNum);

    @Update("UPDATE post SET post_type=#{postType}, post_title=#{postTitle}, post_content=#{postContent} WHERE post_num=#{postNum}")
    public void editPost(UsersPostDto udto);


    // 좋아요 기능

    @Insert("INSERT INTO love VALUES(NULL, #{memberId}, #{postNum}, 1)")
    public void setLove(LoveDto loveDto);
    @Select("SELECT COUNT(*) FROM love WHERE memberId=#{memberId} AND post_num=#{postNum}")
    public int checkCountLove (LoveDto loveDto);
    @Select("SELECT * FROM love WHERE memberId=#{memberId} AND post_num=#{postNum}")
    public LoveDto checkLove (LoveDto loveDto);
    @Update("UPDATE love SET state=1 WHERE memberId=#{memberId} AND post_num=#{postNum}")
    public void updateTrueLove(LoveDto loveDto);
    @Update("UPDATE love SET state=0 WHERE memberId=#{memberId} AND post_num=#{postNum}")
    public void updateFalseLove(LoveDto loveDto);
}
