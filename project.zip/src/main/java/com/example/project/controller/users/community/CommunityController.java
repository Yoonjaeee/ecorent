package com.example.project.controller.users.community;

import com.example.project.dto.UsersPostDto;
import com.example.project.mappers.PostMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/users/community")
public class CommunityController {


    @Autowired
    PostMapper postMapper;

    @GetMapping("/listPost")
    public String getCommunity(){
        return "/users/community/listPost";
    }

    @PostMapping("/listPost")
    @ResponseBody
    public Map<String, Object> GetCommunityList(){
        Map<String, Object> map = new HashMap<>();

        map.put("total",postMapper.getTotalPost());
        map.put("list", postMapper.getCommunityList());

        return map;
    }

    @GetMapping("/post")
    public String getPost(HttpSession session){
        if(session.getAttribute("user")==null){
            return "redirect:/users/member/login";
        }
        return "users/community/post";
    }


    @PostMapping("/post")
    @ResponseBody
    public Map<String, Object> setPost(@ModelAttribute UsersPostDto postDto){
        Map<String, Object> map = new HashMap<>();

        if(postDto!=null){
            postMapper.setPost(postDto);
            map.put("result","good");
        } //예외 추가하기
        return map;
    }

    @GetMapping("/viewPost")
    public String getViewPost(@RequestParam int id, Model model){
        UsersPostDto result = postMapper.viewPost(id);
        model.addAttribute("selectedPost", result);
        return "users/community/viewPost";
    }

    @PostMapping("/viewPost")
    @ResponseBody
    public Map<String, Object> removePost(@RequestParam int postNum){
        Map<String, Object> map = new HashMap<>();
        postMapper.removePost(postNum);

        map.put("result", "success");

        return map;
    }

    @GetMapping("/editPost")
    public String getEditPost(@RequestParam int postNum, Model model){
        UsersPostDto result = postMapper.viewPost(postNum);
        model.addAttribute("selectedPost",result);
        return "/users/community/editPost";
    }

    @PostMapping("/editPost")
    @ResponseBody
    public Map<String, Object> editPost(@ModelAttribute UsersPostDto pdto) {
        Map<String,Object> map = new HashMap<>();
        if(pdto!=null){
            postMapper.editPost(pdto);
            map.put("result","good");
        }else{
            map.put("result","failed");
        }
        return map;
    }

}
