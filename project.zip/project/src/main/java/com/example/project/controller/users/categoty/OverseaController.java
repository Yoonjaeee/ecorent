package com.example.project.controller.users.categoty;

import com.example.project.dto.MemberDto;
import com.example.project.dto.UsersItemDto;
import com.example.project.mappers.CategoryMapper;
import com.example.project.service.category.CategoryService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/users/category/oversea")
public class OverseaController {

    @Autowired
    CategoryService categoryService;
    @Autowired
    CategoryMapper categoryMapper;

    @GetMapping("")
    public String getListOversea(){
        return "/users/category/oversea/listOversea";
    }
    @PostMapping("")
    @ResponseBody
    public Map<String,Object> getItemList(){
        return categoryService.getOverseaList();
    }

    @GetMapping("/postOversea")
    public String getPostOversea(){
        return "/users/category/oversea/postOversea";
    }
    @PostMapping("/postOversea")
    public String setPostOversea(@RequestParam("file") MultipartFile file, @ModelAttribute UsersItemDto itemDto, HttpSession session) throws IOException {
        if(session.getAttribute("user")==null){
            return "redirect:/users/member/login";
        }else{
            MemberDto user = (MemberDto) session.getAttribute("user");
            categoryService.setOverseaInfo(file,itemDto,user.getMemberId());
            return "redirect:/users/category/oversea";
        }
    }

    @GetMapping("/viewOversea")
    public String getViewOversea(@RequestParam int id, Model model){
        model.addAttribute("card",categoryMapper.getviewItem(id));
        return "users/category/oversea/viewOversea";
    }

}
