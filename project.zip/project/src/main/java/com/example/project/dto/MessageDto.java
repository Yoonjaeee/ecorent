package com.example.project.dto;

import org.springframework.cglib.core.Local;
import org.thymeleaf.spring6.processor.SpringErrorClassTagProcessor;

import java.time.LocalDateTime;

public class MessageDto {

    private int msgId;
    private int itemId;
    private int senderId;
    private int receiverId;
    private String msgContent;
    private LocalDateTime msgTime;



    //메시지 리스트를 위한 컬럼들
    private String title;
    private String folderName;
    private String fileName;
    private String memberName;

    public int getMsgId() {
        return msgId;
    }

    public void setMsgId(int msgId) {
        this.msgId = msgId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getSenderId() {
        return senderId;
    }

    public void setSenderId(int senderId) {
        this.senderId = senderId;
    }

    public int getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(int receiverId) {
        this.receiverId = receiverId;
    }

    public String getMsgContent() {
        return msgContent;
    }

    public void setMsgContent(String msgContent) {
        this.msgContent = msgContent;
    }

    public LocalDateTime getMsgTime() {
        return msgTime;
    }

    public void setMsgTime(LocalDateTime msgTime) {
        this.msgTime = msgTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    @Override
    public String toString() {
        return "MessageDto{" +
                "msgId=" + msgId +
                ", itemId=" + itemId +
                ", senderId=" + senderId +
                ", receiverId=" + receiverId +
                ", msgContent='" + msgContent + '\'' +
                ", msgTime=" + msgTime +
                ", title='" + title + '\'' +
                ", folderName='" + folderName + '\'' +
                ", fileName='" + fileName + '\'' +
                ", memberName='" + memberName + '\'' +
                '}';
    }
}
