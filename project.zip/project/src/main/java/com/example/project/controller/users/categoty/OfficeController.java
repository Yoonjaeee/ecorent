package com.example.project.controller.users.categoty;

import com.example.project.dto.MemberDto;
import com.example.project.dto.UsersItemDto;
import com.example.project.mappers.CategoryMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/users/office")
public class OfficeController {

    @Autowired
    CategoryMapper categoryMapper;

    @Value("${fileDir}")
    String fileDir;


    @GetMapping("")
    public String getListOffice(){
        return "users/office/listOffice";
    }

    @PostMapping("")
    @ResponseBody
    public Map<String, Object> getItemList(){
        Map<String, Object> map = new HashMap<>();
        if(categoryMapper.getOfficeList().size()==0){
            map.put("list","zero");
        }else{
            map.put("list",categoryMapper.getOfficeList());
        }
        map.put("total",categoryMapper.getOfficeList());
        return map;
    }

    @GetMapping("/viewOffice")
    public String getViewOffice(@RequestParam int id, Model model){
        model.addAttribute("card",categoryMapper.getviewItem(id));
        return "users/office/viewOffice";
    }



    @GetMapping("/postOffice")
    public String getPostOffice(HttpSession session){
        if(session.getAttribute("user")==null){
            return "redirect:/users/member/login";
        }
        return "/users/office/postOffice";
    }

    @PostMapping("/postOffice")
    public String setPostOffice(@RequestParam("file") MultipartFile file, @ModelAttribute UsersItemDto itemDto, HttpSession session) throws IOException {
        if(session.getAttribute("user")==null){
            return "redirect:/users/member/login";
        }else {
            MemberDto user = (MemberDto) session.getAttribute("user");
            String folderName = new SimpleDateFormat("yyyyMMdd").format(System.currentTimeMillis());
            File makeFolder = new File(fileDir + folderName);

            if (!makeFolder.exists()) {
                makeFolder.mkdir();
            }

            //첨부한 파일의 원래이름 가져오기
            String originName = file.getOriginalFilename();
            System.out.println(originName);

            //난수생성 하기
            String uuid = UUID.randomUUID().toString();
            System.out.println(uuid);

            //파일이름의 온점을 기준으로 잘라내기
            String extention = originName.substring(originName.lastIndexOf("."));
            System.out.println(extention);

            //앞서 생성했던 랜덤문자열과 잘라낸 확장자 붙여주기 (이미지를 표시할 때)
            String savedFileName = uuid + extention;
            System.out.println(savedFileName);

            //저장될 이미지의 최종 경로 변수로 지정
            String savedPathFileName = fileDir + folderName + "/" + savedFileName;

            file.transferTo(new File(savedPathFileName));

            itemDto.setMemberId(user.getMemberId());
            itemDto.setFolderName(folderName);
            itemDto.setFileName(savedFileName);
            categoryMapper.setOfficeInfo(itemDto);
            System.out.println(itemDto);
            return "redirect:/users/office";
        }
    }
}
