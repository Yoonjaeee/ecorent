package com.example.project.controller.users.member;

import com.example.project.dto.MemberDto;
import com.example.project.dto.RentalFormDto;
import com.example.project.mappers.MemberMapper;
import com.example.project.mappers.RentalFormMapper;
import com.example.project.service.category.RentalFormService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/users/member")
public class MemberController {

    @Autowired
    MemberMapper memberMapper;

    @Autowired
    RentalFormMapper rentalMapper;

    @Autowired
    RentalFormService rentalService;

    @GetMapping("/login")
    public String getMemberLogin(){
        return "users/member/login";
    }

    @PostMapping("/login")
    @ResponseBody
    public Map<String, Object> loginCheck(@ModelAttribute MemberDto mdto, HttpServletRequest request){
        Map<String, Object> map = new HashMap<>();

        MemberDto member = memberMapper.loginCheck(mdto);

        if(member!=null){
            HttpSession memberSession =  request.getSession();
            memberSession.setAttribute("user",member);
            memberSession.setMaxInactiveInterval(3600);
            map.put("result","good");
        }else{
            map.put("result","bad");
        }

        return map;
    }

    @GetMapping("/join")
    public String getMemberJoin(){
        return "users/member/join";
    }

    @PostMapping("/join")
    @ResponseBody
    public Map<String, Object> setMemberJoin(@ModelAttribute MemberDto mdto){
        Map<String, Object> map = new HashMap<>();

        if(mdto!=null){
            memberMapper.setMemberInfo(mdto);
            map.put("result","good");
        }else{
            map.put("result","bad");
        }
        return map;
    }

    @GetMapping("/logout")
    public String getLogout(HttpServletRequest request, HttpSession hs){
        //현재 요청의 리퍼러 URL 가져오기
        String referer = request.getHeader("referer");

        //로그아웃 처리
        hs.invalidate();

        return "redirect:" + (referer!=null ? referer : "/");
    }

    @GetMapping("/memberInfo/info")
    public String getMemberInfo(HttpSession session){
        MemberDto member = (MemberDto) session.getAttribute("user");
        if(member==null){
            return "redirect:/users/member/login";
        }else{
            return "users/member/memberInfo/info";
        }
    }
    @GetMapping("/memberInfo/sentForms")
    public String getSentForm(HttpSession session){
        if(session.getAttribute("user")==null){
            return "redirect:/users/member/login";
        }else {
            return "users/member/memberInfo/sentForms";
        }
    }
    @PostMapping("/memberInfo/sentForms")
    @ResponseBody
    public Map<String,Object> getSentFormList(String renterId){
        return rentalService.getSentFormList(renterId);
    }

    @GetMapping("/memberInfo/receivedForms")
    public String getMemberRequest(HttpSession session){
        if(session.getAttribute("user")==null){
            return "redirect:/users/member/login";
        }else {
            return "users/member/memberInfo/receivedForms";
        }
    }

    @PostMapping("/memberInfo/receivedForms")
    @ResponseBody
    public Map<String,Object> getRequestList(@RequestParam int memberId){
        return rentalService.getRentalList(memberId);
    }

    @GetMapping("/memberInfo/receivedForms/requestDetail")
    public String getRequestDetail(@RequestParam int id, Model model, HttpSession session){
        MemberDto member = (MemberDto) session.getAttribute("user");
        if(member==null){
            return "redirect:/users/member/login";
        }else{
            rentalService.updateCheckRequest(member.getMemberId(),id);
            model.addAttribute("form",rentalService.getRentalDetail(id));
            model.addAttribute("ownerItem",rentalService.getOwnersItem(id));
            return "users/member/memberInfo/requestDetail";
        }
    }
    @GetMapping("/memberInfo/requestDetail/confirmForm")
    public String confirmForm(@RequestParam int formId){
        rentalService.confirmForm(formId);
        return "redirect:/users/member/memberInfo/receivedForms/requestDetail?id="+formId;
    }
    @GetMapping("/memberInfo/requestDetail/rejectForm")
    public String rejectForm(@RequestParam int formId){
        rentalService.rejectForm(formId);
        return "redirect:/users/member/memberInfo/receivedForms";
    }
}
