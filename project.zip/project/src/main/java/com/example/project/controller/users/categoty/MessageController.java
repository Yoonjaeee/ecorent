package com.example.project.controller.users.categoty;

import com.example.project.dto.MemberDto;
import com.example.project.dto.MessageDto;
import com.example.project.mappers.MemberMapper;
import com.example.project.service.category.MemberService;
import com.example.project.service.category.MessageService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class MessageController {
    @Autowired
    MemberMapper memberMapper;
    @Autowired
    MemberService memberService;
    @Autowired
    MessageService messageService;

    @GetMapping("/users/member/memberInfo/messages")
    public String getMessagesView(HttpSession session){
        if(session.getAttribute("user")==null){
            return "redirect:/users/member/login";
        }else {
            return "users/member/memberInfo/messages";
        }
    }
    @PostMapping("/users/category/car/msgCar")
    public String setMessage(@ModelAttribute MessageDto msgDto, HttpSession session){

        MemberDto user = (MemberDto) session.getAttribute("user");
        msgDto.setSentBy(user.getMemberId());
        System.out.println(msgDto);
        memberMapper.setMessage(msgDto);

        return "redirect:/users/category/car/viewCar?id="+msgDto.getItemId();
    }

    @PostMapping("/users/member/memberInfo/messages")
    @ResponseBody
    public Map<String,Object> getMessageList(HttpSession session){
        MemberDto user = (MemberDto) session.getAttribute("user");
        System.out.println(messageService.getMessageList(user.getMemberId()));
        return messageService.getMessageList(user.getMemberId());
    }

    @PostMapping("/users/member/memberInfo/deleteMsgs")
    @ResponseBody
    public Map<String,Object> setDeleteMsgs(@RequestBody List<MessageDto> selectedMsgs, HttpSession session){
        System.out.println(selectedMsgs);
        Map<String,Object> map = new HashMap<>();
        MemberDto user = (MemberDto) session.getAttribute("user");
        int memberId = user.getMemberId();

        return messageService.setDeleteMsgs(memberId,selectedMsgs);
    }

    @GetMapping("/users/member/memberInfo/msgView")
    public String getmsgView(@RequestParam int memberId, @RequestParam int otherMemberId,@RequestParam int itemId){
        System.out.println("memberId: " + memberId + ", otherMemberId: " + otherMemberId + ", itemId: " + itemId);
        return "/users/member/memberInfo/msgView";
    }

}
