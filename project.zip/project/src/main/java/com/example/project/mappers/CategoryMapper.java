package com.example.project.mappers;

import com.example.project.dto.CarTypeCountDto;
import com.example.project.dto.UsersItemDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface CategoryMapper {
    //자동차 매퍼
    @Insert("INSERT INTO item VALUES(NULL, #{title}, #{name}, #{rentalStartDate}, #{rentalEndDate}, #{rentalPrice}, #{address}, #{content}, NOW(), #{folderName}, #{fileName}, #{carType}, #{carAge}, #{carFuelType}, '자동차', #{memberId})")
    public void setCarInfo(UsersItemDto carDto);
    @Select("SELECT * FROM item WHERE item_category='자동차' ORDER BY num DESC")
    public List<UsersItemDto> getCarList();
    @Select("SELECT COUNT(*) FROM item WHERE item_category='자동차'")
    public int getTotalCar(); //자동차리스트 total 개수
    @Select("SELECT car_type, COUNT(*) as carTypeCount FROM item WHERE item_category='자동차' GROUP BY car_type;")
    public List<CarTypeCountDto> getCountCarType();



    //오피스매퍼

    @Insert("INSERT INTO item VALUES(NULL, #{title}, #{name}, #{rentalStartDate}, #{rentalEndDate}, #{rentalPrice}, #{address}, #{content}, NOW(), #{folderName}, #{fileName}, #{carType}, #{carAge}, #{carFuelType}, '오피스', #{memberId})")
    public void setOfficeInfo(UsersItemDto OfficeDto);

    @Select("SELECT * FROM item WHERE item_category='오피스' ORDER BY num DESC")
    public List<UsersItemDto> getOfficeList();


    //ALL 카테고리 공통
    @Select("SELECT item.*, member.memberName FROM item JOIN member ON item.memberId=member.memberId WHERE item.num = #{num}")
    public UsersItemDto getviewItem(int id);
    @Select("SELECT * FROM item ORDER BY num DESC limit 4")
    public List<UsersItemDto> getNewItemList();

    @Delete("DELETE FROM item WHERE num=#{itemNum}")
    public void deleteItem(int id);

}
