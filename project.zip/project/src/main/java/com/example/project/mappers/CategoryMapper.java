package com.example.project.mappers;

import com.example.project.dto.CarTypeCountDto;
import com.example.project.dto.UsersItemDto;
import org.apache.ibatis.annotations.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@Mapper
public interface CategoryMapper {
    //자동차 매퍼
    @Insert("INSERT INTO item VALUES(NULL, #{title}, #{name}, #{rentalStartDate}, #{rentalEndDate}, #{rentalPrice}, #{address}, #{content}, NOW(), #{folderName}, #{fileName}, #{carType}, #{carAge}, #{carFuelType}, '자동차', #{memberId})")
    public void setCarInfo(UsersItemDto carDto);
    @Select("SELECT * FROM item WHERE item_category='자동차' ORDER BY itemId DESC")
    public List<UsersItemDto> getCarList();
    @Select("SELECT COUNT(*) FROM item WHERE item_category='자동차'")
    public int getTotalCar(); //자동차리스트 total 개수
    @Select("SELECT car_type, COUNT(*) as carTypeCount FROM item WHERE item_category='자동차' GROUP BY car_type;")
    public List<CarTypeCountDto> getCountCarType();

    @Select("SELECT * FROM item WHERE car_type=#{carType} ORDER BY itemId DESC")
    public List<UsersItemDto> getcarTypeList(String carType); //자동차 타입별 리스트 가져오기

    @Update("UPDATE item SET title=#{title},name=#{name},rentalStartDate=#{rentalStartDate},rentalEndDate=#{rentalEndDate},rentalPrice=#{rentalPrice},address=#{address},content=#{content},folderName=#{folderName},fileName=#{fileName},car_type=#{carType},car_age=#{carAge},car_fuelType=#{carFuelType} WHERE itemId=#{itemId}")
    public void updateCar(UsersItemDto itemDto);


    //오피스매퍼

    @Insert("INSERT INTO item VALUES(NULL, true, #{title}, #{name}, #{rentalStartDate}, #{rentalEndDate}, #{rentalPrice}, #{address}, #{carrier}, #{content}, NOW(), #{folderName}, #{fileName}, #{carType}, #{carAge}, #{carFuelType}, '오피스', #{memberId})")
    public void setOfficeInfo(UsersItemDto OfficeDto);

    @Select("SELECT * FROM item WHERE item_category='오피스' ORDER BY itemId DESC")
    public List<UsersItemDto> getOfficeList();

    @Update("UPDATE item SET title=#{title},name=#{name},rentalStartDate=#{rentalStartDate},rentalEndDate=#{rentalEndDate},rentalPrice=#{rentalPrice},address=#{address},content=#{content},folderName=#{folderName},fileName=#{fileName} WHERE itemId=#{itemId}")
    public void updateOffice(UsersItemDto itemDto);

    //해외렌탈매퍼
    @Insert("INSERT INTO item VALUES(NULL, false, #{title}, #{name}, #{rentalStartDate}, #{rentalEndDate}, #{rentalPrice}, #{address}, #{carrier}, #{content}, NOW(), #{folderName}, #{fileName}, #{carType}, #{carAge}, #{carFuelType}, '해외', #{memberId})")
    public void setOverseaInfo(UsersItemDto overseaDto);

    @Select("SELECT * FROM item WHERE item_category='해외' ORDER BY itemId DESC")
    public List<UsersItemDto> getOverseaList();


    //ALL 카테고리 공통
    @Select("SELECT item.*, member.memberName FROM item JOIN member ON item.memberId=member.memberId WHERE item.itemId = #{itemId}")
    public UsersItemDto getviewItem(int itemId);
    @Select("SELECT * FROM item ORDER BY itemId DESC limit 4")
    public List<UsersItemDto> getNewItemList();

    @Delete("DELETE FROM item WHERE itemId=#{itemId}")
    public void deleteItem(int itemId);

    @Select("SELECT * FROM item WHERE title LIKE CONCAT('%',#{searchWord},'%')")
    public List<UsersItemDto> getMainSearch(String searchWord);


}
