package com.example.project.mappers;

import com.example.project.dto.UsersPostDto;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PostMapper {

    @Insert("INSERT INTO post VALUES(NULL, #{postType}, #{postTitle}, #{postContent}, NOW())")
    public void setPost(UsersPostDto postDto);

    @Select("SELECT COUNT(*) FROM post")
    public int getTotalPost();

    @Select("SELECT * FROM post ORDER BY post_num DESC")
    public List<UsersPostDto> getCommunityList();

    @Select("SELECT * FROM POST WHERE post_num = #{postNum}")
    public UsersPostDto viewPost(int id);

    @Delete("DELETE FROM post WHERE post_num=#{postNum}")
    public void removePost(int postNum);

    @Update("UPDATE post SET post_type=#{postType}, post_title=#{postTitle}, post_content=#{postContent} WHERE post_num=#{postNum}")
    public void editPost(UsersPostDto udto);





}
